
#'
#'
#' This function calculates multivariate location and scatter estimate with a high breakdown point, using the FDB algorithm.
#'
#' @param x a numeric matrix or data frame.Missing values (NaN's) and infinite values (Inf's) are allowed: observations (rows) with missing or infinite values will automatically be excluded from the computations.
#' @param alpha numeric parameter controlling the size of the subsets, i.e., alpha*n
#' observations are used for computing FDB estimators. Allowed values are between 0.5 and 1 and the default is 0.75.
#' @param depth a character string specifying the depth notions. Possible values are "pro" and "l2".
#' Default value "pro" is to use the projection depth.
#' @param k the number of the projection direction if "pro" is used.  Default value is 1000.
#' @return center: The robust location of the data, obtained after reweighting.
#' @return cov: The robust covariance matrix, obtained after reweighting.
#' @return best: The subset of h points that have the deepest depth value.
#' @return raw.center:	The raw FDB location of the data.
#' @return raw.cov: The raw MCD covariance matrix (multiplied by a empirical factor).
#' @return rew.md: The Mahalanobis distance of each observation (distance from the classical center of the data, relative to the classical shape of the data).
#' @export
FDB<-function(x,alpha=0.75,depth="pro",k=1000){
  na.x <- complete.cases(x)
  if (sum(na.x) != nrow(x)) {
    x <- x[na.x, ]
    warning(paste("Observetions #:", which(na.x == 0), "where removed"))
  }
  Data <- data.matrix(x)
  n <- nrow(Data)
  p <- ncol(Data)
  if(depth== "pro"){
    pro<-depth.projection(x,x,num.directions = k)
    index11<-order(pro,decreasing = TRUE)[1:(alpha*n)]}
  if(depth== "l2"){
    l2<-l2_fast(x)
    index11<-order(l2,decreasing = TRUE)[1:(alpha*n)]
  }
  subset<-x[index11,]
  hat_mu<-colMeans(subset)
  hat_sigma<-cov(subset)
  MD_c0<-mahalanobis(x,hat_mu,hat_sigma)
  c_s<-median(MD_c0)/qchisq(0.5,p)
  sigma_raw<-c_s*hat_sigma
  MD <- mahalanobis(x,hat_mu,sigma_raw)
  trunc<-which(MD>=qchisq(0.975,p))
  x_trunc<-x[-trunc,]
  center<-colMeans(x_trunc)
  cov<-cov(x_trunc)
  return(list(center=center,cov=cov,best=index11,raw.center=hat_mu,raw.cov=sigma_raw,rew.md=MD))
}


l2_fast<-function(data){
  dis<-as.matrix(dist(data))
  depths=1/(1+colMeans(dis))
  return(depths)
}
